﻿// See https://aka.ms/new-console-template for more information
using System;

class PuntoDos
{
    static void Main()
    {
        Console.WriteLine("Generador de Tablas de Multiplicar con Desafío");
        Console.Write("Ingrese el número mínimo del rango: ");
        int minimo = int.Parse(Console.ReadLine());
        Console.Write("Ingrese el número máximo del rango: ");
        int maximo = int.Parse(Console.ReadLine());

        Random random = new Random();

        for (int i = minimo; i <= maximo; i++)
        {
            int numeroOculto = random.Next(1, 11); // Genera un número aleatorio entre 1 y 10 para ocultar en la tabla.
            Console.WriteLine($"\nTabla del {i}:");

            for (int j = 1; j <= 10; j++)
            {
                if (j == numeroOculto)
                {
                    Console.Write($"{i} x ? = {i * j}\t");
                }
                else
                {
                    Console.Write($"{i} x {j} = {i * j}\t");
                }
            }

            Console.Write("\nIngrese su respuesta: ");
            int respuesta = int.Parse(Console.ReadLine());

            if (respuesta == numeroOculto)
            {
                Console.WriteLine("¡Correcto! ¡Has adivinado el número oculto!");
            }
            else
            {
                Console.WriteLine($"Incorrecto. El número oculto era {numeroOculto}.");
            }
        }
    }
}