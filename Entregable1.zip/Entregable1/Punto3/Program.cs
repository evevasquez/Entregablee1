﻿// See https://aka.ms/new-console-template for more information
using System;

class Puntotres
{
    static void Main()
    {
        Console.WriteLine("Verificador de Número Especial");
        Console.Write("Ingrese un número: ");
        
        if (int.TryParse(Console.ReadLine(), out int numero))
        {
            if (EsNumeroEspecial(numero))
            {
                Console.WriteLine($"{numero} es un número especial.");
            }
            else
            {
                Console.WriteLine($"{numero} no es un número especial.");
            }
        }
        else
        {
            Console.WriteLine("Entrada no válida. Debe ingresar un número entero.");
        }
    }

    static bool EsNumeroEspecial(int num)
    {
        // Verificar si es divisible entre 5
        if (num % 5 != 0)
        {
            return false;
        }

        // Verificar si no es divisible entre 2 ni 3
        if (num % 2 == 0 || num % 3 == 0)
        {
            return false;
        }

        // Calcular la suma de sus dígitos
        int sumaDigitos = 0;
        int numeroAbsoluto = Math.Abs(num); // Asegurarse de que trabajamos con un número positivo

        while (numeroAbsoluto > 0)
        {
            sumaDigitos += numeroAbsoluto % 10; // Sumar el último dígito
            numeroAbsoluto /= 10; // Eliminar el último dígito
        }

        // Verificar si la suma de sus dígitos es mayor a 10
        return sumaDigitos > 10;
    }
}