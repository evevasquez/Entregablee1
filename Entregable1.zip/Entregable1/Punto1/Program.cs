﻿using System;

Console.WriteLine("Calculadora de Fracciones");
Console.Write("Ingrese la primera fracción (en el formato a/b): ");
string input1 = Console.ReadLine();
Console.Write("Ingrese el operador (+, -, *, /): ");
string operador = Console.ReadLine();
Console.Write("Ingrese la segunda fracción (en el formato a/b): ");
string input2 = Console.ReadLine();

if (Fraccion.TryParse(input1, out Fraccion fraccion1) && Fraccion.TryParse(input2, out Fraccion fraccion2))
{
    Fraccion resultado = Calcular(fraccion1, fraccion2, operador);
    if (resultado != null)
    {
        Console.WriteLine($"El resultado es: {resultado}");
    }
    else
    {
        Console.WriteLine("Operación no válida.");
    }
}
else
{
    Console.WriteLine("Entrada no válida. Asegúrate de ingresar fracciones en el formato a/b.");
}

Fraccion? Calcular(Fraccion fraccion1, Fraccion fraccion2, string operador)
{
    switch (operador)
    {
        case "+":
            return fraccion1 + fraccion2;
        case "-":
            return fraccion1 - fraccion2;
        case "*":
            return fraccion1 * fraccion2;
        case "/":
            if (fraccion2.Numerador != 0)
            {
                return fraccion1 / fraccion2;
            }
            else
            {
                Console.WriteLine("Error: División por cero.");
                return null;
            }
        default:
            Console.WriteLine("Operador no válido.");
            return null;
    }
}

class Fraccion
{
    public int Numerador { get; set; }
    public int Denominador { get; set; }

    public Fraccion(int numerador, int denominador)
    {
        Numerador = numerador;
        Denominador = denominador;
    }

    public static bool TryParse(string input, out Fraccion? fraccion)
    {
        fraccion = null;
        string[] partes = input.Split('/');
        if (partes.Length == 2 && int.TryParse(partes[0], out int numerador) && int.TryParse(partes[1], out int denominador))
        {
            fraccion = new Fraccion(numerador, denominador);
            return true;
        }
        return false;
    }

    public override string ToString()
    {
        return $"{Numerador}/{Denominador}";
    }

    public static Fraccion operator +(Fraccion a, Fraccion b)
    {
        int nuevoDenominador = a.Denominador * b.Denominador;
        int nuevoNumerador = a.Numerador * b.Denominador + b.Numerador * a.Denominador;
        return Simplificar(new Fraccion(nuevoNumerador, nuevoDenominador));
    }

    public static Fraccion operator -(Fraccion a, Fraccion b)
    {
        int nuevoDenominador = a.Denominador * b.Denominador;
        int nuevoNumerador = a.Numerador * b.Denominador - b.Numerador * a.Denominador;
        return Simplificar(new Fraccion(nuevoNumerador, nuevoDenominador));
    }

    public static Fraccion operator *(Fraccion a, Fraccion b)
    {
        int nuevoDenominador = a.Denominador * b.Denominador;
        int nuevoNumerador = a.Numerador * b.Numerador;
        return Simplificar(new Fraccion(nuevoNumerador, nuevoDenominador));
    }

    public static Fraccion operator /(Fraccion a, Fraccion b)
    {
        int nuevoDenominador = a.Denominador * b.Numerador;
        int nuevoNumerador = a.Numerador * b.Denominador;
        return Simplificar(new Fraccion(nuevoNumerador, nuevoDenominador));
    }

    static int MCD(int a, int b)
    {
        if (b == 0)
            return a;
        else
            return MCD(b, a % b);
    }

    static Fraccion Simplificar(Fraccion fraccion)
    {
        int mcd = MCD(fraccion.Numerador, fraccion.Denominador);
        return new Fraccion(fraccion.Numerador / mcd, fraccion.Denominador / mcd);
    }
}
