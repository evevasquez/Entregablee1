﻿// See https://aka.ms/new-console-template for more information
using System;
using System.Collections.Generic;

class PuntoCuatro
{
    static void Main()
    {
        Console.WriteLine("Adivinanza de Frase Oculta");
        Console.WriteLine("Tienes que adivinar las palabras ocultas en la siguiente frase:");
        Console.WriteLine("Frase: \"El __ juega __ el ___\"");
        Console.WriteLine("Tienes 10 intentos en total.");

        string[] palabrasOcultas = { "gato", "en", "jardin" };
        List<string> palabrasAdivinadas = new List<string>();
        int intentosRestantes = 10;

        while (intentosRestantes > 0 && palabrasAdivinadas.Count < palabrasOcultas.Length)
        {
            Console.WriteLine($"Intentos restantes: {intentosRestantes}");
            Console.Write("Ingresa una palabra: ");
            string palabraIngresada = Console.ReadLine().ToLower();

            if (palabrasAdivinadas.Contains(palabraIngresada))
            {
                Console.WriteLine("Ya adivinaste esa palabra antes. Intenta con otra.");
            }
            else if (Array.Exists(palabrasOcultas, palabra => palabra.Equals(palabraIngresada)))
            {
                Console.WriteLine("¡Correcto! Has adivinado una palabra.");
                palabrasAdivinadas.Add(palabraIngresada);
            }
            else
            {
                Console.WriteLine("Incorrecto. Esa palabra no está en la frase.");
                intentosRestantes--;
            }
        }

        if (palabrasAdivinadas.Count == palabrasOcultas.Length)
        {
            Console.WriteLine("\n¡Felicitaciones! Has adivinado todas las palabras.");
            Console.WriteLine("La frase completa es: \"El gato juega en el jardín\"");
        }
        else
        {
            Console.WriteLine("\nHas agotado todos tus intentos. Has perdido.");
            Console.WriteLine("La frase completa era: \"El gato juega en el jardín\"");
        }
    }
}